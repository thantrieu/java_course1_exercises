package net.braniumacademy;

import java.util.ArrayList;
import java.util.List;
import javax.swing.ComboBoxModel;
import javax.swing.event.ListDataListener;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class MyComboBoxModel implements ComboBoxModel<String> {
    private List<String> majors;
    private Object seleObject;
    
    public MyComboBoxModel() {
        majors = new ArrayList<>();
        majors.add("Công nghệ thông tin");
        majors.add("Công nghệ đa phương tiện");
        majors.add("Điện tử");
        majors.add("Viễn thông");
        majors.add("Quản trị kinh doanh");
        majors.add("Tài chính ngân hàng");
    }
    
    @Override
    public void setSelectedItem(Object anItem) {
        seleObject = anItem;
    }

    @Override
    public Object getSelectedItem() {
        return seleObject;
    }

    @Override
    public int getSize() {
        return majors.size();
    }

    @Override
    public String getElementAt(int index) {
        return majors.get(index);
    }

    @Override
    public void addListDataListener(ListDataListener l) {
    }

    @Override
    public void removeListDataListener(ListDataListener l) {
    }
    
}
