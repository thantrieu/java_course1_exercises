package net.braniumacademy;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class ImageFilter extends FileFilter {

    @Override
    public boolean accept(File f) {
        if (f.isDirectory()) {
            return true;
        }
        var ex = FileFilterUtils.getExtension(f).toLowerCase();
        if (ex != null) {
            if (ex.equals(FileFilterUtils.JPG) || 
                    ex.equals(FileFilterUtils.PNG) || 
                    ex.equals(FileFilterUtils.GIF)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String getDescription() {
        return "Image files";
    }

}
