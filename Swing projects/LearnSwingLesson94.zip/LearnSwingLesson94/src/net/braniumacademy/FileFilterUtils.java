package net.braniumacademy;

import java.io.File;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class FileFilterUtils {
    public static final String JPG = ".jpg";
    public static final String PNG = ".png";
    public static final String GIF = ".gif";
    
    public static String getExtension(File file) {
        String ex = null;
        var fileName = file.getName();
        var endDotIndex = fileName.lastIndexOf(".");
        if(endDotIndex > 0) {
            ex = fileName.substring(endDotIndex);
        }
        return ex;
    }
}
