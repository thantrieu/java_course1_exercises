package net.braniumacademy;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class MediaFilter extends FileFilter {

    @Override
    public boolean accept(File f) {
        if (f.isDirectory()) {
            return true;
        }
        var ex = FileFilterUtils.getExtension(f).toLowerCase();
        if (ex != null) {
            if (ex.equals(FileFilterUtils.MP3) || 
                    ex.equals(FileFilterUtils.MP4) || 
                    ex.equals(FileFilterUtils.MKV) ||
                    ex.equals(FileFilterUtils.M4A) ||
                    ex.equals(FileFilterUtils.AVI) || 
                    ex.equals(FileFilterUtils.MVW)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String getDescription() {
        return "Video and Audio files";
    }

}
