package net.braniumacademy;

import java.io.File;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class FileFilterUtils {
    public static final String MP3 = ".mp3";
    public static final String MP4 = ".mp4";
    public static final String MKV = ".mkv";
    public static final String M4A = ".m4a";
    public static final String MVW = ".mvw";
    public static final String AVI = ".avi";
    
    public static String getExtension(File file) {
        String ex = null;
        var fileName = file.getName();
        var endDotIndex = fileName.lastIndexOf(".");
        if(endDotIndex > 0) {
            ex = fileName.substring(endDotIndex).toLowerCase();
        }
        return ex;
    }
}
