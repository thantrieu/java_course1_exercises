package net.braniumacademy.model;

import java.io.Serializable;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class Student  implements Serializable {
    
}
