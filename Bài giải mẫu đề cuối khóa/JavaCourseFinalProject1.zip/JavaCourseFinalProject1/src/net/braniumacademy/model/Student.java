package net.braniumacademy.model;

import java.util.Objects;
import net.braniumacademy.controller.InfoFilterImp;
import net.braniumacademy.exception.InvalidStudentIdException;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class Student extends Person {

    private String studentId;
    private String studentClass;
    private String major;
    private String academicYear;

    public Student() {
    }

    public Student(String studentId) {
        setStudentId(studentId);
    }

    public Student(String id, String studentId) {
        super(id);
        setStudentId(studentId);
    }

    public Student(String studentId, String studentClass,
            String major, String academicYear) {
        setStudentId(studentId);
        this.studentClass = studentClass;
        this.major = major;
        this.academicYear = academicYear;
    }

    public Student(String studentId, String studentClass,
            String major, String academicYear, String id) {
        this(id, studentId);
        this.studentClass = studentClass;
        this.major = major;
        this.academicYear = academicYear;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        var infoFilter = new InfoFilterImp();
        try {
            if (infoFilter.isStudentIdValid(studentId)) {
                this.studentId = studentId;
            }
        } catch (InvalidStudentIdException ex) {
            ex.printStackTrace();
        }
    }

    public String getStudentClass() {
        return studentClass;
    }

    public void setStudentClass(String studentClass) {
        this.studentClass = studentClass;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    @Override
    public String toString() {
        return "Student{" + "studentId=" + studentId + ", studentClass="
                + studentClass + ", major=" + major + ", academicYear="
                + academicYear + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 59 * hash + Objects.hashCode(this.studentId);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Student other = (Student) obj;
        if (!Objects.equals(this.studentId, other.studentId)) {
            return false;
        }
        return true;
    }

}
