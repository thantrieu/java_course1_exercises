package net.braniumacademy.model;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class Registering {
    
}
