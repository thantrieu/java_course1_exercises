package net.braniumacademy.controller.sorter;

import java.util.Comparator;
import net.braniumacademy.model.Registering;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class SortRegisteringByRegisterTimeASC implements Comparator<Registering> {

    @Override
    public int compare(Registering o1, Registering o2) {
        return (int)(o1.getRegistedTime().getTime() 
                - o2.getRegistedTime().getTime());
    }
    
}