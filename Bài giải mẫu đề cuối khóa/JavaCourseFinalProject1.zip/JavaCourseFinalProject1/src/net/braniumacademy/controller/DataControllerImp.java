package net.braniumacademy.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import net.braniumacademy.controller.sorter.SortSubjectByNameASC;
import net.braniumacademy.controller.sorter.SortSubjectByNameDESC;
import net.braniumacademy.controller.sorter.SortSubjectByNumOfLessonASC;
import net.braniumacademy.controller.sorter.SortSubjectByNumOfLessonDESC;
import net.braniumacademy.model.Subject;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public class DataControllerImp implements DataController {
    
    @Override
    public <T> void writeToFile(List<T> data, String fileName) {
        try ( FileOutputStream fos = new FileOutputStream(fileName);  
                ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(data);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @Override
    public <T> List<T> readDataFromFile(String fileName) {
        List<T> data = new ArrayList<>();
        File file = new File(fileName);
        if (file.length() > 0) {
            try ( FileInputStream fis = new FileInputStream(fileName);  
                    ObjectInputStream ois = new ObjectInputStream(fis)) {
                data = (List<T>) ois.readObject();
            } catch (FileNotFoundException | ClassNotFoundException ex) {
                ex.printStackTrace();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        return data;
    }
    
    @Override
    public void updateSubjectId(List<Subject> subjects) {
        if (subjects != null && subjects.size() > 0) {
            var id = subjects.get(subjects.size() - 1).getId();
            Subject.setSid(id + 1);
        }
    }
    
    @Override
    public void sortSubjectByNameASC(List<Subject> subjects) {
        subjects.sort(new SortSubjectByNameASC());
    }
    
    @Override
    public void sortSubjectByNameDESC(List<Subject> subjects) {
        subjects.sort(new SortSubjectByNameDESC());
    }
    
    @Override
    public void sortSubjectByNumOfLessonASC(List<Subject> subjects) {
        subjects.sort(new SortSubjectByNumOfLessonASC());
    }
    
    @Override
    public void sortSubjectByNumOfLessonDESC(List<Subject> subjects) {
        subjects.sort(new SortSubjectByNumOfLessonDESC());
    }
}
