package net.braniumacademy.controller;

import net.braniumacademy.exception.InvalidDateOfBirthException;
import net.braniumacademy.exception.InvalidEmailException;
import net.braniumacademy.exception.InvalidNameException;
import net.braniumacademy.exception.InvalidPersonIdException;
import net.braniumacademy.exception.InvalidPhoneNumberException;
import net.braniumacademy.exception.InvalidStudentIdException;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public interface InfoFilter {

    boolean isStudentIdValid(String studentId) 
            throws InvalidStudentIdException;

    boolean isDOBValid(String dob) throws InvalidDateOfBirthException;

    boolean isEmailValid(String email) throws InvalidEmailException;

    boolean isNameValid(String name) throws InvalidNameException;

    boolean isPersonIdValid(String personId) throws InvalidPersonIdException;

    boolean isPhoneNumberValid(String phoneNumber) 
            throws InvalidPhoneNumberException;
}
