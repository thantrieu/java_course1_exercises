package net.braniumacademy.controller;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public interface RegisteringController {
    
}
