package net.braniumacademy.controller;

import java.util.List;

/**
 *
 * @author braniumacademy <braniumacademy.net>
 */
public interface DataController {

    <T> void writeToFile(List<T> data, String fileName);

    <T> List<T> readDataFromFile(String fileName);
}
